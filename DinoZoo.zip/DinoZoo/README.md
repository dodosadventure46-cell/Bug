# Dino Zoo Tycoon (Godot 4.3, pixel art top-down)

Game tycoon kebun binatang dinosaurus. Pengunjung masuk dari pintu di atas, bayar tiket, berkeliling lewat jalan
tanah buatanmu, melihat dino, jajan, duduk, ke toilet. Ada pengunjung nakal (merokok & buang sampah) dan petugas kebersihan.
Target: Android (APK lewat GitHub Actions), bisa juga PC. Bahasa: Indonesia.

## Cara build APK (tanpa ekstrak zip)
1. Unggah `DinoZoo.zip` ke root repo GitHub (jangan diekstrak). Kalau sudah ada, timpa dengan yang baru.
2. File `.github/workflows/build-apk.yml` di repo (isi sama dengan `build-apk.yml` yang dikirim terpisah).
3. Tab Actions -> Run workflow. Unduh `DinoZoo-APK` di Artifacts. APK ditandatangani debug (aktifkan "instal dari sumber tak dikenal").

## Cara main
- Bar bawah: pilih alat. "Geser kamera" = seret layar untuk menggeser peta. "Jalan" = seret untuk melukis jalan tanah (menyambung otomatis).
- Area paling atas (pasir) adalah luar kebun binatang; pengunjung muncul di sana dan masuk lewat gerbang. Bangun di bawah gerbang.
- Bangun kandang (Rp800) dekat jalan -> panel kandang terbuka otomatis -> "Beli Triceratops" / "Upgrade". Ketuk kandang kapan saja untuk membukanya lagi.
- Kandang HARUS punya jalan di sampingnya yang tersambung ke gerbang, kalau tidak pengunjung tidak akan sampai.
- Warung/suvenir = uang tambahan. Toilet, bangku, pohon, lampu, tong menambah daya tarik. Tong sampah mencegah pembeli membuang sampah sembarangan.
- Pengunjung bertanda "!" itu nakal: merokok di bangku & buang sampah. Ketuk dia untuk mengusir. Sampah mengurangi daya tarik:
  ketuk sampah untuk memungut, atau "Sewa Petugas" (Rp400 + gaji Rp30/hari) - petugas berpatroli di jalanmu dan memungut sampah sendiri.
- Atas: atur harga tiket (+/-). Tiket terlalu mahal = pengunjung sedikit. Tiap hari ada biaya pakan, perawatan, gaji.
- Simpan otomatis tiap akhir hari dan saat aplikasi ditutup (menu: Lanjutkan).

## Struktur
- `scripts/main.gd`    logika utama: peta, bangun, ekonomi, sampah, petugas, UI (lewat kode), input, simpan/muat
- `scripts/game_data.gd` SEMUA angka keseimbangan (harga, kapasitas, gerbang, peluang pengunjung nakal, gaji, dll)
- `scripts/dino.gd` AI dino | `scripts/visitor.gd` AI pengunjung/pengunjung nakal/petugas (A* lewat jalan setapak, aktivitas bergantian)
- `scripts/building.gd` kandang & fasilitas | `scripts/trash.gd` sampah (digambar lewat kode) | `scripts/art.gd` pemuat gambar/animasi
- `assets/` sprite satuan hasil potong. Animasi dibaca otomatis dari `nama_0.png, nama_1.png, ...`
- `tools/slice_sheets.py` memotong `tools/source_sheets/*.png` jadi `assets/`. Bikin juga siklus jalan sendiri (SYNTH_WALK) dan 16 tile jalan.
- `tools/PROMPT_SPRITE_BARU.md` prompt sprite tambahan (kandang pixel art, petugas, pengunjung nakal, animasi jalan asli)

## Catatan untuk yang melanjutkan (AI lain / manusia)
Status: versi kedua, BELUM DIUJI di Godot (dibuat tanpa mesin Godot; pengguna sudah berhasil build & menjalankan versi pertama).
Kalau ada error, mulai dari `scripts/main.gd` dan `scripts/visitor.gd`.
Sprite opsional: taruh `janitor.png` / `rude.png` (4 baris arah down,left,right,up x 4 kolom, latar transparan) di `tools/source_sheets/`
lalu jalankan `python tools/slice_sheets.py`; kalau tidak ada, petugas & pengunjung nakal memakai sprite pengunjung yang diberi warna.
Yang belum dikerjakan:
1. Sprite kandang masih gaya realistis/miring (tidak serasi) -> ganti (prompt ada). Setelah ganti, sesuaikan `ENCLOSURE_INTERIOR` di game_data.gd.
2. Animasi jalan saat ini sintetis dari 1 pose (kaki bergantian lewat kode). Kalau ada sheet jalan asli yang bagus, set SYNTH_WALK=False di slicer.
3. Dinosaurus lain (Stegosaurus, T-Rex, ...) + pilihan jenis dino di panel kandang.
4. Suara/musik, misi/tujuan bertahap, rating bintang, event (dino kabur), pengunjung duduk di bangku dengan pose duduk.
