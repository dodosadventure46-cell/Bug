# Dino Zoo Tycoon (Godot 4.3, pixel art top-down)

Game tycoon kebun binatang dinosaurus. Pengunjung bayar tiket + belanja = penghasilan; kandang bisa di-upgrade.
Target: Android (APK lewat GitHub Actions), bisa juga PC. Bahasa: Indonesia.

## Cara build APK (tanpa ekstrak zip)
1. Unggah `DinoZoo.zip` ke root repo GitHub (jangan diekstrak).
2. Buat file `.github/workflows/build-apk.yml` di repo (isi sama dengan `build-apk.yml` yang dikirim terpisah).
3. Tab Actions -> Run workflow. Unduh `DinoZoo-APK` di Artifacts. APK ditandatangani debug (aktifkan "instal dari sumber tak dikenal").

## Cara main
- Bawah: pilih alat. "Geser kamera" = seret layar untuk menggeser peta. "Jalan" = seret untuk melukis jalan setapak.
- Bangun kandang (Rp800), HARUS ada jalan di sampingnya yang tersambung ke gerbang (kiri), lalu ketuk kandang -> Beli Triceratops / Upgrade.
- Warung & suvenir menghasilkan uang tambahan; toilet, bangku, pohon, lampu menambah daya tarik.
- Atas: atur harga tiket (+/-). Tiket terlalu mahal = pengunjung sedikit. Tiap hari ada biaya pakan dino.
- Simpan otomatis tiap akhir hari dan saat aplikasi ditutup (menu: Lanjutkan).

## Struktur
- `scripts/main.gd`    logika utama: peta, bangun, ekonomi, UI (dibuat lewat kode), input, simpan/muat
- `scripts/game_data.gd` SEMUA angka keseimbangan (harga, kapasitas, level kandang, hari, dll)
- `scripts/dino.gd`    AI dino (jalan/makan/tidur) | `scripts/visitor.gd` AI pengunjung (A* lewat jalan setapak)
- `scripts/building.gd` kandang & fasilitas | `scripts/art.gd` pemuat gambar/animasi (otomatis baca `nama_0.png, nama_1.png, ...`)
- `assets/` sprite satuan hasil potong. `tools/slice_sheets.py` memotong `tools/source_sheets/*.png` jadi `assets/`
- `tools/PROMPT_SPRITE_BARU.md` prompt untuk generate ulang kandang pixel art & animasi jalan

## Catatan untuk yang melanjutkan (AI lain / manusia)
Status: versi pertama LENGKAP tapi BELUM DIUJI di Godot (dibuat tanpa mesin Godot). Kalau error saat dijalankan, mulai dari
`scripts/main.gd` (paling banyak kode). Yang perlu dikerjakan berikutnya:
1. Ganti sprite kandang (sekarang gaya realistis/miring, tidak serasi) & animasi jalan Triceratops (frame mirip). Lihat PROMPT_SPRITE_BARU.md.
2. Sesuaikan `ENCLOSURE_INTERIOR` di game_data.gd setelah sprite kandang diganti.
3. Tambah dinosaurus lain (Stegosaurus, T-Rex, dst): tambah sprite `tri_*` versi baru + data jenis dino di game_data.gd, dan pilihan jenis di panel kandang.
4. Suara/musik, menu pengaturan, tujuan/misi bertahap, rating bintang, event (dino kabur), staf.
5. Jalan tidak punya sambungan tepi otomatis (semua pakai tile batu yang sama).
