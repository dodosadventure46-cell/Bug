class_name Art
extends RefCounted
# Pemuat gambar. Kalau file sprite tidak ada, dipakai kotak magenta supaya game tidak crash.

static var _cache: Dictionary = {}

static func tex(path: String) -> Texture2D:
	if _cache.has(path):
		return _cache[path]
	var t: Texture2D = null
	if ResourceLoader.exists(path):
		t = load(path)
	else:
		var img := Image.create(48, 48, false, Image.FORMAT_RGBA8)
		img.fill(Color(1, 0, 1, 0.6))
		t = ImageTexture.create_from_image(img)
	_cache[path] = t
	return t

# spec: {"nama_anim": ["res://awalan_file", fps]}  -> memuat awalan_0.png, awalan_1.png, ... sampai tidak ada.
static func make_frames(spec: Dictionary) -> SpriteFrames:
	var sf := SpriteFrames.new()
	if sf.has_animation("default"):
		sf.remove_animation("default")
	for anim in spec.keys():
		var prefix: String = spec[anim][0]
		var fps: float = spec[anim][1]
		sf.add_animation(anim)
		sf.set_animation_speed(anim, fps)
		sf.set_animation_loop(anim, true)
		var i: int = 0
		while ResourceLoader.exists("%s_%d.png" % [prefix, i]):
			sf.add_frame(anim, tex("%s_%d.png" % [prefix, i]))
			i += 1
		if i == 0:
			sf.add_frame(anim, tex("%s_0.png" % prefix))
	return sf
