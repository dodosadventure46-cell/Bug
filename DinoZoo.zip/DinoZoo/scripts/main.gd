extends Node2D
# Dino Zoo Tycoon - logika utama: peta, bangun, ekonomi, UI, simpan/muat.

const T: int = 64
const SAVE_PATH: String = "user://dinozoo.json"

var money: int = 0
var day: int = 1
var day_time: float = 0.0
var ticket: int = 15
var day_income: int = 0
var spawn_t: float = 3.0
var playing: bool = false
var tool: String = "geser"
var selected: Building = null
var toast_t: float = 0.0
var pressing: bool = false
var dragged: bool = false
var press_pos: Vector2 = Vector2.ZERO
var hover: Vector2i = Vector2i(-1, -1)

var paths: Dictionary = {}
var occupied: Dictionary = {}
var buildings: Array = []
var visitors: Array = []
var astar: AStarGrid2D = null

var tt: Dictionary = {}
var grass_variants: Array = []

var enclosure_layer: Node2D
var entities: Node2D
var fx_layer: Node2D
var ghost: Node2D
var camera: Camera2D

var ui_theme: Theme
var lbl_money: Label
var lbl_day: Label
var lbl_vis: Label
var lbl_appeal: Label
var lbl_ticket: Label
var lbl_toast: Label
var lbl_panel: Label
var panel: PanelContainer
var btn_buy: Button
var btn_up: Button
var title: Control
var btn_continue: Button

func _ready() -> void:
	randomize()
	for n in ["grass_a", "grass_b", "grass_yellow", "grass_flowers", "rocks_a", "rocks_b", "rocks_c", "rocks_d", "stone"]:
		tt[n] = Art.tex("res://assets/tiles/%s.png" % n)
	grass_variants = [tt["grass_a"], tt["grass_a"], tt["grass_a"], tt["grass_a"],
		tt["grass_b"], tt["grass_b"], tt["grass_b"], tt["grass_b"],
		tt["grass_yellow"], tt["grass_flowers"],
		tt["rocks_a"], tt["rocks_b"], tt["rocks_c"], tt["rocks_d"]]
	enclosure_layer = Node2D.new()
	add_child(enclosure_layer)
	entities = Node2D.new()
	entities.y_sort_enabled = true
	add_child(entities)
	fx_layer = Node2D.new()
	fx_layer.z_index = 40
	add_child(fx_layer)
	ghost = Node2D.new()
	ghost.z_index = 30
	add_child(ghost)
	ghost.draw.connect(_draw_ghost)
	camera = Camera2D.new()
	add_child(camera)
	camera.position = Vector2(640, 704)
	_setup_astar()
	_build_ui()
	_build_title()
	queue_redraw()

# ---------------------------------------------------------------- peta

func _draw() -> void:
	draw_rect(Rect2(0, 0, GameData.GRID_W * T, GameData.GRID_H * T), Color(0.30, 0.52, 0.18))
	for x in GameData.GRID_W:
		for y in GameData.GRID_H:
			var tex: Texture2D
			if paths.has(Vector2i(x, y)):
				tex = tt["stone"]
			else:
				var h: int = ((x * 73856093) ^ (y * 19349663)) & 0x7fffffff
				tex = grass_variants[h % grass_variants.size()]
			draw_texture_rect(tex, Rect2(x * T - 1, y * T - 1, T + 2, T + 2), false)

func _draw_ghost() -> void:
	if not playing or not _in_bounds(hover):
		return
	if tool == "geser" or tool == "hapus":
		return
	if tool == "jalan":
		ghost.draw_rect(Rect2(hover.x * T, hover.y * T, T, T), Color(1, 1, 1, 0.3))
		return
	var size: Vector2i = GameData.BUILDINGS[tool]["size"]
	var tl: Vector2i = _top_left(hover, size)
	var col: Color = Color(0.2, 1.0, 0.2, 0.3) if _area_free(tl, size) else Color(1.0, 0.2, 0.2, 0.3)
	ghost.draw_rect(Rect2(tl.x * T, tl.y * T, size.x * T, size.y * T), col)

func _setup_astar() -> void:
	astar = AStarGrid2D.new()
	astar.region = Rect2i(0, 0, GameData.GRID_W, GameData.GRID_H)
	astar.cell_size = Vector2(T, T)
	astar.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
	astar.update()
	astar.fill_solid_region(astar.region, true)

func _in_bounds(t: Vector2i) -> bool:
	return t.x >= 0 and t.y >= 0 and t.x < GameData.GRID_W and t.y < GameData.GRID_H

func world_to_tile(w: Vector2) -> Vector2i:
	return Vector2i(floori(w.x / T), floori(w.y / T))

func foot(t: Vector2i) -> Vector2:
	return Vector2(t.x * T + T * 0.5, t.y * T + T * 0.8)

func _top_left(tap: Vector2i, size: Vector2i) -> Vector2i:
	return tap - Vector2i(int((size.x - 1) * 0.5), int((size.y - 1) * 0.5))

func _area_free(tl: Vector2i, size: Vector2i) -> bool:
	for x in range(tl.x, tl.x + size.x):
		for y in range(tl.y, tl.y + size.y):
			var t := Vector2i(x, y)
			if not _in_bounds(t) or occupied.has(t) or paths.has(t):
				return false
	return true

func _add_path(t: Vector2i) -> void:
	paths[t] = true
	astar.set_point_solid(t, false)
	queue_redraw()

func _add_gate() -> void:
	for x in range(0, 3):
		for y in range(9, 11):
			occupied[Vector2i(x, y)] = "gerbang"
	var s := Sprite2D.new()
	var tex: Texture2D = Art.tex("res://assets/facilities/gerbang.png")
	s.texture = tex
	s.centered = false
	s.offset = Vector2(-tex.get_width() * 0.5, -tex.get_height())
	s.position = Vector2(96, 11 * T)
	entities.add_child(s)

func _add_building(kind: String, tl: Vector2i, lv: int = 1, dino_count: int = 0) -> Building:
	var b := Building.new()
	var parent: Node = enclosure_layer if kind == "kandang" else entities
	parent.add_child(b)
	b.setup(kind, tl)
	for i in range(1, lv):
		b.upgrade()
	for x in range(tl.x, tl.x + b.size.x):
		for y in range(tl.y, tl.y + b.size.y):
			occupied[Vector2i(x, y)] = b
	buildings.append(b)
	for i in dino_count:
		b.add_dino(entities)
	return b

func _remove_building(b: Building) -> void:
	var refund: int = int(int(GameData.BUILDINGS[b.kind]["cost"]) * 0.5)
	refund += int(b.dinos.size() * GameData.DINO_COST * 0.5)
	money += refund
	for x in range(b.tile.x, b.tile.x + b.size.x):
		for y in range(b.tile.y, b.tile.y + b.size.y):
			occupied.erase(Vector2i(x, y))
	b.clear_dinos()
	buildings.erase(b)
	if selected == b:
		selected = null
		panel.visible = false
	b.queue_free()

func _clear_world() -> void:
	for layer in [enclosure_layer, entities, fx_layer]:
		for c in layer.get_children():
			c.queue_free()
	paths.clear()
	occupied.clear()
	buildings.clear()
	visitors.clear()
	selected = null
	panel.visible = false
	_setup_astar()
	queue_redraw()

func _start_world_common() -> void:
	_add_gate()
	if not paths.has(GameData.GATE_TILE):
		_add_path(GameData.GATE_TILE)
	playing = true
	title.visible = false
	camera.position = Vector2(640, 704)
	spawn_t = 3.0
	day_time = 0.0
	day_income = 0
	_set_tool("geser")

func _new_game() -> void:
	_clear_world()
	money = GameData.START_MONEY
	day = 1
	ticket = GameData.DEFAULT_TICKET
	for x in range(GameData.GATE_TILE.x, 15):
		_add_path(Vector2i(x, GameData.GATE_TILE.y))
	_start_world_common()
	_toast("Selamat datang, Juragan! Bangun kandang di dekat jalan, lalu beli dinosaurus.")

# ---------------------------------------------------------------- jalur pengunjung

func _adjacent_path_tiles(b: Building) -> Array:
	var res: Array = []
	for x in range(b.tile.x - 1, b.tile.x + b.size.x + 1):
		for y in range(b.tile.y - 1, b.tile.y + b.size.y + 1):
			var inside: bool = x >= b.tile.x and x < b.tile.x + b.size.x and y >= b.tile.y and y < b.tile.y + b.size.y
			if not inside and paths.has(Vector2i(x, y)):
				res.append(Vector2i(x, y))
	return res

func find_route_to_tile(from: Vector2i, to: Vector2i) -> Array:
	if not astar.is_in_boundsv(from) or not astar.is_in_boundsv(to):
		return []
	var r: Array = astar.get_id_path(from, to)
	return r

func find_route(from: Vector2i, b: Building) -> Array:
	var best: Array = []
	for t in _adjacent_path_tiles(b):
		var p: Array = find_route_to_tile(from, t)
		if p.size() > 0 and (best.is_empty() or p.size() < best.size()):
			best = p
	return best

func route_to_points(route: Array) -> Array:
	var out: Array = []
	for t in route:
		out.append(foot(t))
	return out

func _pick_stops() -> Array:
	var cand: Array = []
	for b: Building in buildings:
		if b.kind == "kandang":
			if b.dinos.size() > 0:
				cand.append(b)
				cand.append(b)
		elif b.kind == "warung" or b.kind == "suvenir":
			cand.append(b)
	cand.shuffle()
	var n: int = mini(cand.size(), randi_range(2, 4))
	var picked: Array = []
	for b in cand:
		if picked.size() < n and not picked.has(b):
			picked.append(b)
	return picked

func _total_appeal() -> float:
	var a: float = 0.0
	for b: Building in buildings:
		a += b.appeal()
	return a

func _spawn_interval() -> float:
	var ap: float = _total_appeal()
	var base: float = 9.0 / (1.0 + ap / 14.0)
	var demand: float = clampf(1.5 - float(ticket) / (10.0 + ap * 0.8), 0.1, 1.3)
	return clampf(base / demand, 1.5, 30.0)

func _spawn_visitor() -> void:
	var v := Visitor.new()
	entities.add_child(v)
	v.setup(self, GameData.GATE_TILE, _pick_stops())
	visitors.append(v)
	earn(ticket, v.position)

func visitor_left(v: Visitor) -> void:
	visitors.erase(v)

func visit(v: Visitor, b: Building) -> void:
	if not is_instance_valid(b):
		return
	var def: Dictionary = GameData.BUILDINGS[b.kind]
	if int(def["sale"]) > 0 and randf() < float(def["chance"]):
		earn(int(def["sale"]), v.position)

func earn(amount: int, pos: Vector2) -> void:
	money += amount
	day_income += amount
	_float_text(pos, "+Rp%d" % amount, Color(1, 0.9, 0.3))

func _float_text(pos: Vector2, text: String, col: Color) -> void:
	var l := Label.new()
	l.text = text
	l.position = pos + Vector2(-24, -80)
	l.add_theme_font_size_override("font_size", 22)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	fx_layer.add_child(l)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y - 40.0, 1.2)
	tw.tween_property(l, "modulate:a", 0.0, 1.2)
	tw.chain().tween_callback(l.queue_free)

# ---------------------------------------------------------------- loop

func _process(delta: float) -> void:
	if not playing:
		return
	day_time += delta
	if day_time >= GameData.DAY_LENGTH:
		_end_day()
	spawn_t -= delta
	if spawn_t <= 0.0:
		spawn_t = _spawn_interval()
		if visitors.size() < GameData.MAX_VISITORS:
			_spawn_visitor()
	if toast_t > 0.0:
		toast_t -= delta
		if toast_t <= 0.0:
			lbl_toast.visible = false
	_update_hud()

func _end_day() -> void:
	var dino_n: int = 0
	for b: Building in buildings:
		dino_n += b.dinos.size()
	var cost: int = dino_n * GameData.DINO_FEED + buildings.size() * 2
	money -= cost
	_toast("Hari %d selesai. Pemasukan Rp %s, biaya pakan & perawatan Rp %s." % [day, fmt(day_income), fmt(cost)])
	day += 1
	day_time = 0.0
	day_income = 0
	save_game()

func fmt(n: int) -> String:
	var s: String = str(absi(n))
	var out: String = ""
	var c: int = 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		c += 1
		if c % 3 == 0 and i > 0:
			out = "." + out
	return ("-" if n < 0 else "") + out

func _toast(text: String) -> void:
	lbl_toast.text = text
	lbl_toast.visible = true
	toast_t = 4.0

func _update_hud() -> void:
	lbl_money.text = "Rp " + fmt(money)
	lbl_day.text = "Hari %d (%d%%)" % [day, int(day_time / GameData.DAY_LENGTH * 100.0)]
	lbl_vis.text = str(visitors.size())
	lbl_appeal.text = "Daya tarik %d" % int(_total_appeal())
	lbl_ticket.text = "Tiket Rp %s" % fmt(ticket)

# ---------------------------------------------------------------- input

func _to_world(p: Vector2) -> Vector2:
	return get_canvas_transform().affine_inverse() * p

func _unhandled_input(event: InputEvent) -> void:
	if not playing:
		return
	var paint_tool: bool = tool == "jalan" or tool == "hapus"
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		var wp: Vector2 = _to_world(event.position)
		hover = world_to_tile(wp)
		if event.pressed:
			pressing = true
			dragged = false
			press_pos = event.position
			if paint_tool:
				_paint_at(hover)
		else:
			if pressing and not dragged and not paint_tool:
				_tap(hover)
			pressing = false
		ghost.queue_redraw()
	elif event is InputEventMouseMotion:
		hover = world_to_tile(_to_world(event.position))
		if pressing:
			if event.position.distance_to(press_pos) > 12.0:
				dragged = true
			if paint_tool:
				_paint_at(hover)
			elif dragged:
				camera.position -= event.relative
				_clamp_camera()
		ghost.queue_redraw()

func _clamp_camera() -> void:
	var half: Vector2 = get_viewport_rect().size * 0.5
	camera.position.x = clampf(camera.position.x, half.x, maxf(half.x, GameData.GRID_W * T - half.x))
	camera.position.y = clampf(camera.position.y, half.y, maxf(half.y, GameData.GRID_H * T - half.y))

func _paint_at(t: Vector2i) -> void:
	if not _in_bounds(t):
		return
	if tool == "jalan":
		if paths.has(t) or occupied.has(t):
			return
		if money < GameData.PATH_COST:
			_toast("Uang tidak cukup")
			return
		money -= GameData.PATH_COST
		_add_path(t)
	elif tool == "hapus":
		var o = occupied.get(t)
		if o is Building:
			_remove_building(o)
		elif paths.has(t) and t != GameData.GATE_TILE:
			paths.erase(t)
			astar.set_point_solid(t, true)
			money += 2
			queue_redraw()

func _tap(t: Vector2i) -> void:
	if not _in_bounds(t):
		return
	var o = occupied.get(t)
	if o is Building and o.kind == "kandang":
		_open_panel(o)
		return
	panel.visible = false
	if GameData.BUILDINGS.has(tool):
		_place(tool, t)

func _place(kind: String, tap: Vector2i) -> void:
	var def: Dictionary = GameData.BUILDINGS[kind]
	var size: Vector2i = def["size"]
	var tl: Vector2i = _top_left(tap, size)
	if not _area_free(tl, size):
		_toast("Tidak bisa dibangun di sini (ada jalan/bangunan atau di luar peta)")
		return
	var cost: int = int(def["cost"])
	if money < cost:
		_toast("Uang tidak cukup")
		return
	money -= cost
	_add_building(kind, tl)
	if kind == "kandang":
		_toast("Kandang dibangun. Pastikan ada jalan di sampingnya, lalu ketuk kandang untuk beli dino.")

func _set_tool(k: String) -> void:
	tool = k
	panel.visible = false
	ghost.queue_redraw()

# ---------------------------------------------------------------- panel kandang

func _open_panel(b: Building) -> void:
	selected = b
	panel.visible = true
	_refresh_panel()

func _refresh_panel() -> void:
	if selected == null or not is_instance_valid(selected):
		panel.visible = false
		return
	var b: Building = selected
	lbl_panel.text = "Kandang Level %d\nDinosaurus: %d / %d\nDaya tarik: %d" % [b.level, b.dinos.size(), b.capacity(), int(b.appeal())]
	btn_buy.text = "Beli Triceratops (Rp %s)" % fmt(GameData.DINO_COST)
	btn_buy.disabled = b.dinos.size() >= b.capacity()
	if b.level >= GameData.ENCLOSURE_LEVELS.size():
		btn_up.text = "Level maksimum"
		btn_up.disabled = true
	else:
		btn_up.text = "Upgrade ke Level %d (Rp %s)" % [b.level + 1, fmt(int(GameData.ENCLOSURE_LEVELS[b.level - 1]["upgrade"]))]
		btn_up.disabled = false

func _buy_dino() -> void:
	if selected == null or not is_instance_valid(selected):
		return
	if selected.dinos.size() >= selected.capacity():
		_toast("Kandang penuh. Upgrade dulu untuk menambah kapasitas.")
		return
	if money < GameData.DINO_COST:
		_toast("Uang tidak cukup")
		return
	money -= GameData.DINO_COST
	selected.add_dino(entities)
	_refresh_panel()

func _upgrade() -> void:
	if selected == null or not is_instance_valid(selected):
		return
	var cost: int = int(GameData.ENCLOSURE_LEVELS[selected.level - 1]["upgrade"])
	if money < cost:
		_toast("Uang tidak cukup")
		return
	money -= cost
	selected.upgrade()
	_toast("Kandang naik ke Level %d!" % selected.level)
	_refresh_panel()

# ---------------------------------------------------------------- simpan / muat

func save_game() -> void:
	var data: Dictionary = {"money": money, "day": day, "ticket": ticket, "paths": [], "buildings": []}
	for t in paths.keys():
		data["paths"].append([t.x, t.y])
	for b: Building in buildings:
		data["buildings"].append({"k": b.kind, "x": b.tile.x, "y": b.tile.y, "lv": b.level, "d": b.dinos.size()})
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(data))

func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		return false
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return false
	var data = JSON.parse_string(f.get_as_text())
	if typeof(data) != TYPE_DICTIONARY:
		return false
	_clear_world()
	money = int(data.get("money", GameData.START_MONEY))
	day = int(data.get("day", 1))
	ticket = int(data.get("ticket", GameData.DEFAULT_TICKET))
	for p in data.get("paths", []):
		_add_path(Vector2i(int(p[0]), int(p[1])))
	for bd in data.get("buildings", []):
		var k: String = str(bd.get("k", ""))
		if GameData.BUILDINGS.has(k):
			_add_building(k, Vector2i(int(bd["x"]), int(bd["y"])), int(bd.get("lv", 1)), int(bd.get("d", 0)))
	_start_world_common()
	return true

func _notification(what: int) -> void:
	if (what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST) and playing:
		save_game()

# ---------------------------------------------------------------- UI

func _icon(path: String) -> TextureRect:
	var r := TextureRect.new()
	r.texture = Art.tex(path)
	r.custom_minimum_size = Vector2(32, 32)
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	return r

func _label(text: String = "") -> Label:
	var l := Label.new()
	l.text = text
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 60)
	b.pressed.connect(cb)
	return b

func _build_ui() -> void:
	ui_theme = Theme.new()
	ui_theme.default_font_size = 22
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = ui_theme
	layer.add_child(root)
	var vb := VBoxContainer.new()
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_theme_constant_override("separation", 0)
	root.add_child(vb)

	# bar atas
	var top := PanelContainer.new()
	vb.add_child(top)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 16)
	top.add_child(hb)
	hb.add_child(_icon("res://assets/icons/coin.png"))
	lbl_money = _label()
	hb.add_child(lbl_money)
	lbl_day = _label()
	hb.add_child(lbl_day)
	hb.add_child(_icon("res://assets/icons/visitor.png"))
	lbl_vis = _label()
	hb.add_child(lbl_vis)
	lbl_appeal = _label()
	hb.add_child(lbl_appeal)
	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.add_child(sp)
	var bm := _button("-", _change_ticket.bind(-5))
	bm.custom_minimum_size = Vector2(52, 52)
	hb.add_child(bm)
	lbl_ticket = _label()
	hb.add_child(lbl_ticket)
	var bp := _button("+", _change_ticket.bind(5))
	bp.custom_minimum_size = Vector2(52, 52)
	hb.add_child(bp)
	var bmenu := _button("Menu", _to_title)
	bmenu.custom_minimum_size = Vector2(90, 52)
	hb.add_child(bmenu)

	# area tengah (toast + panel kandang)
	var mid := Control.new()
	mid.size_flags_vertical = Control.SIZE_EXPAND_FILL
	mid.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(mid)
	lbl_toast = _label()
	lbl_toast.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	lbl_toast.offset_top = 12.0
	lbl_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl_toast.add_theme_color_override("font_outline_color", Color.BLACK)
	lbl_toast.add_theme_constant_override("outline_size", 8)
	lbl_toast.visible = false
	mid.add_child(lbl_toast)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mid.add_child(center)
	panel = PanelContainer.new()
	panel.visible = false
	center.add_child(panel)
	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 10)
	panel.add_child(pv)
	lbl_panel = _label()
	pv.add_child(lbl_panel)
	btn_buy = _button("", _buy_dino)
	pv.add_child(btn_buy)
	btn_up = _button("", _upgrade)
	pv.add_child(btn_up)
	pv.add_child(_button("Tutup", func(): panel.visible = false))

	# bar bawah (alat)
	var bottom := PanelContainer.new()
	vb.add_child(bottom)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 92)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	bottom.add_child(scroll)
	var tools := HBoxContainer.new()
	tools.add_theme_constant_override("separation", 8)
	scroll.add_child(tools)
	var group := ButtonGroup.new()
	for k in GameData.TOOL_ORDER:
		var b := Button.new()
		b.toggle_mode = true
		b.button_group = group
		b.custom_minimum_size = Vector2(110, 76)
		if k == "geser":
			b.text = "Geser\nkamera"
			b.button_pressed = true
		elif k == "hapus":
			b.text = "Hapus\n(refund)"
		elif k == "jalan":
			b.text = "Jalan\nRp%d" % GameData.PATH_COST
		else:
			b.text = "%s\nRp%s" % [GameData.BUILDINGS[k]["name"], fmt(int(GameData.BUILDINGS[k]["cost"]))]
		b.pressed.connect(_set_tool.bind(k))
		tools.add_child(b)

func _change_ticket(d: int) -> void:
	ticket = clampi(ticket + d, 0, 200)

func _build_title() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 20
	add_child(layer)
	title = Control.new()
	title.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	title.theme = ui_theme
	layer.add_child(title)
	var bg := ColorRect.new()
	bg.color = Color(0.22, 0.45, 0.20)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	title.add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	title.add_child(center)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	center.add_child(box)
	var pic := TextureRect.new()
	pic.texture = Art.tex("res://assets/dino/tri_walk_down_0.png")
	pic.custom_minimum_size = Vector2(160, 160)
	pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	box.add_child(pic)
	var l := Label.new()
	l.text = "DINO ZOO TYCOON"
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 56)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 10)
	box.add_child(l)
	var sub := Label.new()
	sub.text = "Jadilah juragan kebun binatang dinosaurus!"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(sub)
	var b1 := _button("Main Baru", _new_game)
	b1.custom_minimum_size = Vector2(320, 64)
	box.add_child(b1)
	btn_continue = _button("Lanjutkan", _continue_game)
	btn_continue.custom_minimum_size = Vector2(320, 64)
	btn_continue.disabled = not FileAccess.file_exists(SAVE_PATH)
	box.add_child(btn_continue)

func _continue_game() -> void:
	if not load_game():
		_toast("Tidak ada data tersimpan")

func _to_title() -> void:
	if playing:
		save_game()
	playing = false
	title.visible = true
	btn_continue.disabled = not FileAccess.file_exists(SAVE_PATH)
