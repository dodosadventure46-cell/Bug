class_name Visitor
extends Node2D
# Pengunjung (normal / nakal) dan petugas kebersihan. Semua jalan lewat jalan setapak (A*).
# kind: "normal" | "rude" | "janitor"

static var frames_cache: Dictionary = {}

var main: Node = null
var kind: String = "normal"
var sprite: AnimatedSprite2D = null
var cid: int = 0
var pts: Array = []
var plan: Array = []
var cur_tile: Vector2i = Vector2i.ZERO
var cur_act: Dictionary = {}
var act_type: String = ""
var act_tile: Vector2i = Vector2i.ZERO
var wait: float = 0.0
var entering: bool = false
var leaving: bool = false
var speed: float = 54.0
var smoking: bool = false
var puff_t: float = 0.0
var litter_t: float = 7.0

static func frames_for(k: String, c: int) -> SpriteFrames:
	var key: String = "%s_%d" % [k, c]
	if frames_cache.has(key):
		return frames_cache[key]
	var spec: Dictionary = {}
	for d in ["down", "left", "right", "up"]:
		var prefix: String = "res://assets/visitors/v%d_%s" % [c, d]
		if k == "janitor" and ResourceLoader.exists("res://assets/janitor/jan_walk_%s_0.png" % d):
			prefix = "res://assets/janitor/jan_walk_%s" % d
		elif k == "rude" and ResourceLoader.exists("res://assets/rude/rude_walk_%s_0.png" % d):
			prefix = "res://assets/rude/rude_walk_%s" % d
		spec["walk_" + d] = [prefix, 6.0]
	var sf: SpriteFrames = Art.make_frames(spec)
	frames_cache[key] = sf
	return sf

func _add_marker(text: String, col: Color) -> void:
	var l := Label.new()
	l.text = text
	l.size = Vector2(90, 24)
	l.position = Vector2(-45, -98)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 18)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(l)

func setup(m: Node, k: String, start_tile: Vector2i, plan_list: Array) -> void:
	main = m
	kind = k
	cur_tile = start_tile
	plan = plan_list
	cid = 2 if kind == "janitor" else randi() % 4
	sprite = AnimatedSprite2D.new()
	sprite.sprite_frames = frames_for(kind, cid)
	add_child(sprite)
	_play("walk_down")
	sprite.stop()
	if kind == "janitor":
		speed = 62.0
		if not ResourceLoader.exists("res://assets/janitor/jan_walk_down_0.png"):
			sprite.modulate = Color(1.0, 0.72, 0.3)
		_add_marker("Petugas", Color(1.0, 0.85, 0.3))
		position = main.foot(start_tile)
		_next()
	else:
		if kind == "rude":
			if not ResourceLoader.exists("res://assets/rude/rude_walk_down_0.png"):
				sprite.modulate = Color(1.0, 0.6, 0.6)
			_add_marker("!", Color(1.0, 0.2, 0.2))
		# masuk dari luar: muncul di area luar, jalan lewat gerbang, lalu masuk
		entering = true
		var gx: float = main.arch_x()
		position = Vector2(randf_range(2.0, 12.0) * GameData.TILE, 1.3 * GameData.TILE)
		pts = [Vector2(gx, 2.6 * GameData.TILE), Vector2(gx, 3.8 * GameData.TILE), main.foot(start_tile)]

func _play(anim: String) -> void:
	if sprite.animation != anim:
		var t: Texture2D = sprite.sprite_frames.get_frame_texture(anim, 0)
		sprite.offset = Vector2(0, -t.get_height() * 0.5)
		sprite.play(anim)
	elif not sprite.is_playing():
		sprite.play(anim)

func _process(delta: float) -> void:
	if sprite == null:
		return
	if wait > 0.0:
		wait -= delta
		sprite.stop()
		sprite.frame = 0
		if smoking:
			puff_t -= delta
			if puff_t <= 0.0:
				puff_t = 0.55
				main.puff(position + Vector2(10, -50))
		if wait <= 0.0:
			_end_activity()
			_next()
		return
	if pts.is_empty():
		_arrived()
		return
	var target: Vector2 = pts[0]
	var d: Vector2 = target - position
	var step: float = speed * delta
	if d.length() <= step:
		position = target
		cur_tile = main.world_to_tile(position)
		pts.remove_at(0)
		return
	var dir: Vector2 = d.normalized()
	sprite.speed_scale = speed / 54.0
	position += dir * step
	if absf(dir.x) > absf(dir.y):
		_play("walk_right" if dir.x > 0.0 else "walk_left")
	else:
		_play("walk_down" if dir.y > 0.0 else "walk_up")
	if kind == "rude" and not entering and not leaving:
		litter_t -= delta
		if litter_t <= 0.0:
			litter_t = randf_range(6.0, 10.0)
			main.drop_trash(cur_tile, -1)

func _arrived() -> void:
	if entering:
		entering = false
		main.pay_ticket(self)
		_next()
	elif leaving:
		main.visitor_left(self)
		queue_free()
	elif not cur_act.is_empty():
		var a: Dictionary = cur_act
		cur_act = {}
		if a.has("b") and not is_instance_valid(a["b"]):
			_next()
		else:
			_start_activity(a)
	else:
		_next()

func _start_activity(a: Dictionary) -> void:
	var t: String = a["type"]
	act_type = t
	if t == "toilet":
		wait = 4.0
		visible = false
	elif t == "sit":
		wait = randf_range(5.0, 8.0)
	elif t == "smoke":
		wait = 9.0
		smoking = true
		main.rude_alert()
	elif t == "buy":
		wait = randf_range(2.0, 4.0)
		main.visit(self, a["b"])
	elif t == "watch":
		wait = randf_range(4.0, 7.0)
	elif t == "clean":
		wait = 2.0
		act_tile = a["tile"]
	else:
		wait = randf_range(0.6, 1.8)

func _end_activity() -> void:
	visible = true
	if act_type == "smoke":
		smoking = false
		main.drop_trash(cur_tile, 2)
		main.drop_trash(cur_tile, 0)
	elif act_type == "buy":
		main.maybe_litter(self)
	elif act_type == "clean":
		main.clean_tile(act_tile)
	act_type = ""

func _next() -> void:
	if leaving:
		return
	if kind == "janitor":
		_janitor_next()
		return
	while not plan.is_empty():
		var a: Dictionary = plan.pop_front()
		var route: Array = []
		if a.has("b"):
			if not is_instance_valid(a["b"]):
				continue
			route = main.find_route(cur_tile, a["b"])
		else:
			var t: Vector2i = main.random_path_tile_near(cur_tile, 9)
			route = main.find_route_to_tile(cur_tile, t)
		if route.is_empty():
			continue
		pts = main.route_to_points(route)
		cur_act = a
		return
	leave()

func _janitor_next() -> void:
	var r: Dictionary = main.nearest_trash(cur_tile)
	if not r.is_empty():
		pts = main.route_to_points(r["route"])
		cur_act = {"type": "clean", "tile": r["tile"]}
		return
	var t: Vector2i = main.random_path_tile_near(cur_tile, 14)
	var route: Array = main.find_route_to_tile(cur_tile, t)
	if route.is_empty():
		wait = 1.5
		return
	pts = main.route_to_points(route)
	cur_act = {"type": "wander"}

func leave() -> void:
	if leaving:
		return
	leaving = true
	cur_act = {}
	plan.clear()
	smoking = false
	visible = true
	wait = 0.0
	var route: Array = main.find_route_to_tile(cur_tile, GameData.GATE_ENTRY)
	if route.is_empty() and cur_tile != GameData.GATE_ENTRY:
		main.visitor_left(self)
		queue_free()
		return
	pts = main.route_to_points(route)
	var gx: float = main.arch_x()
	pts.append(Vector2(gx, 3.8 * GameData.TILE))
	pts.append(Vector2(gx, 2.6 * GameData.TILE))
	pts.append(Vector2(randf_range(2.0, 12.0) * GameData.TILE, 0.6 * GameData.TILE))

func kick() -> void:
	speed = 95.0
	leave()
