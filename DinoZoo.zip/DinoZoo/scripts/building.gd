class_name Building
extends Node2D
# Satu bangunan: kandang (punya level & dino) atau fasilitas.

var kind: String = ""
var tile: Vector2i = Vector2i.ZERO   # petak kiri-atas
var size: Vector2i = Vector2i.ONE
var level: int = 1
var dinos: Array = []
var sprite: Sprite2D = null

func setup(k: String, t: Vector2i) -> void:
	kind = k
	tile = t
	size = GameData.BUILDINGS[k]["size"]
	sprite = Sprite2D.new()
	sprite.centered = false
	add_child(sprite)
	_refresh()

func _refresh() -> void:
	var path: String = ""
	if kind == "kandang":
		path = "res://assets/enclosure/kandang_%d.png" % level
	else:
		path = "res://assets/facilities/%s.png" % kind
	var t: Texture2D = Art.tex(path)
	sprite.texture = t
	sprite.offset = Vector2(-t.get_width() * 0.5, -t.get_height())
	var bottom: float = (tile.y + size.y) * GameData.TILE
	if kind == "kandang":
		bottom += 10.0
	position = Vector2((tile.x + size.x * 0.5) * GameData.TILE, bottom)

func interior_rect() -> Rect2:
	var t: Texture2D = sprite.texture
	var w: float = t.get_width()
	var h: float = t.get_height()
	var f: Rect2 = GameData.ENCLOSURE_INTERIOR
	var x0: float = position.x - w * 0.5
	var y0: float = position.y - h
	return Rect2(x0 + w * f.position.x, y0 + h * f.position.y, w * f.size.x, h * f.size.y)

func capacity() -> int:
	return int(GameData.ENCLOSURE_LEVELS[level - 1]["cap"])

func appeal() -> float:
	if kind == "kandang":
		return dinos.size() * GameData.DINO_APPEAL * float(GameData.ENCLOSURE_LEVELS[level - 1]["mult"])
	return float(GameData.BUILDINGS[kind]["appeal"])

func add_dino(layer: Node) -> void:
	var d := Dino.new()
	layer.add_child(d)
	d.setup(interior_rect())
	dinos.append(d)

func clear_dinos() -> void:
	for d in dinos:
		if is_instance_valid(d):
			d.queue_free()
	dinos.clear()

func upgrade() -> void:
	if level < GameData.ENCLOSURE_LEVELS.size():
		level += 1
		_refresh()
		for d in dinos:
			if is_instance_valid(d):
				d.area = interior_rect()
