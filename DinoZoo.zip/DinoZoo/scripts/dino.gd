class_name Dino
extends Node2D
# Satu dinosaurus (Triceratops) yang berkeliaran di dalam kandang: jalan, makan, tidur.

static var frames_cache: SpriteFrames = null

var area: Rect2 = Rect2()
var sprite: AnimatedSprite2D = null
var state: String = "idle"
var timer: float = 0.0
var target: Vector2 = Vector2.ZERO
var speed: float = 26.0
var face_right: bool = false
var bob_t: float = 0.0

func setup(rect: Rect2) -> void:
	area = rect
	if frames_cache == null:
		frames_cache = Art.make_frames({
			"walk_down": ["res://assets/dino/tri_walk_down", 7.0],
			"walk_left": ["res://assets/dino/tri_walk_left", 7.0],
			"walk_right": ["res://assets/dino/tri_walk_right", 7.0],
			"walk_up": ["res://assets/dino/tri_walk_up", 7.0],
			"eat": ["res://assets/dino/tri_eat", 4.0],
			"sleep": ["res://assets/dino/tri_sleep", 2.0],
		})
	sprite = AnimatedSprite2D.new()
	sprite.sprite_frames = frames_cache
	add_child(sprite)
	position = _random_point()
	_pick_state()

func _random_point() -> Vector2:
	return Vector2(randf_range(area.position.x, area.end.x), randf_range(area.position.y, area.end.y))

func _play(anim: String) -> void:
	if sprite.animation != anim:
		var t: Texture2D = sprite.sprite_frames.get_frame_texture(anim, 0)
		sprite.offset = Vector2(0, -t.get_height() * 0.5)
		sprite.play(anim)
	elif not sprite.is_playing():
		sprite.play(anim)

func _pick_state() -> void:
	var r: float = randf()
	if r < 0.55:
		state = "walk"
		target = _random_point()
	elif r < 0.8:
		state = "eat"
		timer = randf_range(3.0, 6.0)
		sprite.flip_h = face_right
		_play("eat")
	else:
		state = "sleep"
		timer = randf_range(5.0, 9.0)
		sprite.flip_h = face_right
		_play("sleep")

func _process(delta: float) -> void:
	if sprite == null:
		return
	if state == "walk":
		var d: Vector2 = target - position
		if d.length() < 3.0:
			sprite.position = Vector2.ZERO
			sprite.rotation = 0.0
			_pick_state()
			return
		var dir: Vector2 = d.normalized()
		position += dir * speed * delta
		var anim: String = "walk_down"
		if absf(dir.x) > absf(dir.y):
			anim = "walk_right" if dir.x > 0.0 else "walk_left"
			face_right = dir.x > 0.0
		else:
			anim = "walk_down" if dir.y > 0.0 else "walk_up"
		sprite.flip_h = false
		_play(anim)
		# goyangan kecil supaya gerakan terasa hidup walau frame jalan mirip
		bob_t += delta * 9.0
		sprite.position.y = -absf(sin(bob_t)) * 3.0
		sprite.rotation = sin(bob_t) * 0.045
	else:
		sprite.position = Vector2.ZERO
		sprite.rotation = 0.0
		timer -= delta
		if timer <= 0.0:
			_pick_state()
