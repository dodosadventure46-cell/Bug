class_name Trash
extends Node2D
# Sampah di jalan (digambar lewat kode): 0 = kaleng, 1 = kertas, 2 = puntung rokok.

var tile: Vector2i = Vector2i.ZERO
var kind: int = 0

func _draw() -> void:
	var o := Color(0.1, 0.08, 0.08)
	if kind == 0:
		draw_rect(Rect2(-6, -9, 12, 16), o)
		draw_rect(Rect2(-5, -8, 10, 14), Color(0.72, 0.74, 0.8))
		draw_rect(Rect2(-5, -3, 10, 3), Color(0.85, 0.2, 0.2))
	elif kind == 1:
		draw_rect(Rect2(-8, -6, 16, 12), o)
		draw_rect(Rect2(-7, -5, 14, 10), Color(0.95, 0.95, 0.88))
		draw_rect(Rect2(-5, -2, 8, 2), Color(0.65, 0.65, 0.7))
	else:
		draw_rect(Rect2(-8, -3, 16, 6), o)
		draw_rect(Rect2(-7, -2, 10, 4), Color(0.96, 0.92, 0.82))
		draw_rect(Rect2(3, -2, 4, 4), Color(0.9, 0.45, 0.15))
