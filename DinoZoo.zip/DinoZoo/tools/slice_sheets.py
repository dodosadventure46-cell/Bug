#!/usr/bin/env python3
"""Memotong sprite sheet mentah (tools/source_sheets/*.png) jadi sprite satuan di assets/.

Pakai:  python tools/slice_sheets.py        (butuh: pip install pillow numpy)

Ganti sheet di tools/source_sheets/ dengan hasil generate ulang (nama file sama),
ubah jumlah kolom/baris di bagian KONFIGURASI kalau berbeda, lalu jalankan skrip ini.
Latar sheet harus transparan (hasil remove.bg / PNG RGBA).
"""
import os
import numpy as np
from PIL import Image

try:
    from scipy import ndimage  # opsional: dipakai supaya sprite yang saling menempel tetap terpotong utuh
except Exception:
    ndimage = None

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "tools", "source_sheets")
OUT = os.path.join(ROOT, "assets")
ALPHA_T = 24

# ---------------- KONFIGURASI ----------------
WALK_ROWS = ["down", "left", "right", "up"]  # urutan baris sheet jalan Triceratops
WALK_COLS = 4          # jumlah frame jalan per arah di sheet mentah
SYNTH_WALK = True      # True = bikin siklus jalan sendiri dari 1 pose (kaki bergantian + badan naik-turun).
                       # Set False kalau sheet baru sudah punya animasi jalan yang bagus.
EAT_SLEEP_COLS = 4     # frame makan (baris 1) dan tidur (baris 2)
DINO_TARGET_W = 120    # lebar maksimum sprite dino di game (px)
VISITOR_TARGET_H = 62  # tinggi pengunjung di game (px)
VISITOR_DIRS = ["down", "left", "right", "up"]
VISITOR_GROUPS = 4     # jumlah karakter pengunjung
VISITOR_FRAMES = 4
ENCLOSURE_TARGET_W = 300
TILE_NAMES = [
    "grass_a", "grass_b", "grass_yellow", "dirt",
    "stone", "dirt_corner", "dirt_t", "dirt_h",
    "dirt_v", "water", "sand", "grass_flowers",
    "rocks_a", "rocks_b", "rocks_c", "rocks_d",
]
FACILITY_NAMES = ["gerbang", "warung", "suvenir", "toilet", "bangku", "tong", "pohon", "lampu"]
FACILITY_WIDTHS = [190, 130, 130, 130, 80, 44, 110, 44]
ICON_NAMES = ["coin", "upgrade", "hammer", "egg", "visitor", "stars", "meat", "gear"]
# ---------------------------------------------


def load(name):
    return Image.open(os.path.join(SRC, name)).convert("RGBA")


def mask_of(img):
    return np.array(img)[:, :, 3] > ALPHA_T


def runs(profile, min_gap):
    res, start, last, gap = [], None, 0, 0
    for i, v in enumerate(profile):
        if v:
            if start is None:
                start = i
            last = i
            gap = 0
        elif start is not None:
            gap += 1
            if gap >= min_gap:
                res.append((start, last))
                start = None
    if start is not None:
        res.append((start, last))
    return res


def split(profile, n):
    """Bagi profil 1D jadi tepat n bagian (cari celah kosong; kalau gagal bagi rata)."""
    for g in range(80, 0, -1):
        r = runs(profile, g)
        if len(r) == n:
            return r
    idx = np.where(profile)[0]
    a, b = int(idx[0]), int(idx[-1]) + 1
    step = (b - a) / n
    return [(int(a + i * step), int(a + (i + 1) * step) - 1) for i in range(n)]


def tight(m, x0, y0, x1, y1):
    sub = m[y0:y1 + 1, x0:x1 + 1]
    ys = np.where(sub.any(axis=1))[0]
    xs = np.where(sub.any(axis=0))[0]
    return (x0 + int(xs[0]), y0 + int(ys[0]), x0 + int(xs[-1]) + 1, y0 + int(ys[-1]) + 1)


def grid_boxes(img, rows, cols):
    m = mask_of(img)
    out = []
    for (y0, y1) in split(m.any(axis=1), rows):
        row = []
        for (x0, x1) in split(m[y0:y1 + 1].any(axis=0), cols):
            row.append(tight(m, x0, y0, x1, y1))
        out.append(row)
    return out


def comp_boxes(sub, n):
    """Cari n sprite terpisah dalam mask lewat komponen terhubung. Hasil: [(x0,y0,x1,y1)] inklusif, atau None."""
    if ndimage is None:
        return None
    for it in (2, 1, 0):
        dil = ndimage.binary_dilation(sub, iterations=it) if it else sub
        lab, k = ndimage.label(dil)
        if k < n:
            continue
        areas = np.bincount(lab.ravel())[1:]
        objs = ndimage.find_objects(lab)
        big = [i for i in range(k) if areas[i] >= 0.25 * areas.max()]
        if len(big) != n:
            continue
        boxes = {i: [objs[i][1].start, objs[i][0].start, objs[i][1].stop - 1, objs[i][0].stop - 1] for i in big}
        for i in range(k):
            if i in boxes:
                continue
            cxi = (objs[i][1].start + objs[i][1].stop) / 2
            j = min(big, key=lambda b: abs((boxes[b][0] + boxes[b][2]) / 2 - cxi))
            boxes[j][0] = min(boxes[j][0], objs[i][1].start)
            boxes[j][1] = min(boxes[j][1], objs[i][0].start)
            boxes[j][2] = max(boxes[j][2], objs[i][1].stop - 1)
            boxes[j][3] = max(boxes[j][3], objs[i][0].stop - 1)
        return sorted((tuple(v) for v in boxes.values()), key=lambda b: b[0])
    return None


def grouped_boxes(img, rows, groups, per_group):
    """Untuk sheet dengan kelompok (mis. 4 karakter x 4 frame dalam satu baris)."""
    m = mask_of(img)
    row_runs = split(m.any(axis=1), rows)
    grp_runs = split(m.any(axis=0), groups)
    out = []
    for (y0, y1) in row_runs:
        row = []
        for (gx0, gx1) in grp_runs:
            sub = m[y0:y1 + 1, gx0:gx1 + 1]
            cb = comp_boxes(sub, per_group)
            if cb:
                for (bx0, by0, bx1, by1) in cb:
                    row.append(tight(m, gx0 + bx0, y0 + by0, gx0 + bx1, y0 + by1))
            else:
                for (x0, x1) in split(sub.any(axis=0), per_group):
                    row.append(tight(m, gx0 + x0, y0, gx0 + x1, y1))
        out.append(row)
    return out


def resize(img, s):
    w, h = max(1, round(img.width * s)), max(1, round(img.height * s))
    return img.convert("RGBa").resize((w, h), Image.LANCZOS).convert("RGBA")


def uniform(crops, scale):
    rs = [resize(c, scale) for c in crops]
    W, H = max(r.width for r in rs), max(r.height for r in rs)
    res = []
    for r in rs:
        c = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        c.paste(r, ((W - r.width) // 2, H - r.height))
        res.append(c)
    return res


def save(img, *parts):
    p = os.path.join(OUT, *parts)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)


def walk_cycle(base, mode, hip_frac, stride_frac, lift_frac=0.05):
    """4 frame siklus jalan dari satu pose: kaki kiri/kanan digeser bergantian + badan naik-turun.
    mode 'side' = tampak samping (kaki melangkah), 'front' = depan/belakang (kaki terangkat bergantian)."""
    a = np.array(base)[:, :, 3] > ALPHA_T
    ys = np.where(a.any(axis=1))[0]
    xs = np.where(a.any(axis=0))[0]
    top, bot = int(ys[0]), int(ys[-1]) + 1
    left, right = int(xs[0]), int(xs[-1]) + 1
    hh, ww = bot - top, right - left
    hip = top + int(hh * hip_frac)
    cx = (left + right) // 2
    st = max(2, round(ww * stride_frac))
    lift = max(2, round(hh * lift_frac))
    pad = st + 2
    W, H = base.width + pad * 2, base.height + lift + 3
    if mode == "side":
        phases = [(st, 0, -st, 0, 0), (0, 0, 0, 0, -2), (-st, 0, st, 0, 0), (0, 0, 0, 0, -2)]
    else:
        phases = [(0, 0, 0, 0, 0), (0, -lift, 0, 0, -1), (0, 0, 0, 0, 0), (0, 0, 0, -lift, -1)]
    upper = base.crop((0, 0, base.width, hip))
    lower_l = base.crop((0, hip, cx, base.height))
    lower_r = base.crop((cx, hip, base.width, base.height))

    def put(c, region, x0, y0, amp):
        """Tempel bagian kaki; amp != 0 = dimiringkan makin ke bawah (tanpa celah di pinggul)."""
        if amp == 0:
            c.alpha_composite(region, (x0, y0))
            return
        for ry in range(region.height):
            dx = round(amp * (ry + 1) / region.height)
            c.alpha_composite(region.crop((0, ry, region.width, ry + 1)), (x0 + dx, y0 + ry))

    out = []
    for (ldx, ldy, rdx, rdy, bob) in phases:
        c = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        oy = H - base.height
        c.alpha_composite(upper, (pad, oy + bob))
        put(c, lower_l, pad, oy + hip + ldy + bob, ldx)
        put(c, lower_r, pad + cx, oy + hip + rdy + bob, rdx)
        out.append(c)
    return out


def brown_mask(im):
    a = np.array(im.convert("RGBA")).astype(int)
    r, g, b, al = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    return (al > 128) & (r > g + 12) & (r > b + 35) & (r > 100)


def connections(im):
    m = brown_mask(im)
    h, w = m.shape
    c, s, t = w // 2, w // 6, 8
    mask = 0
    if m[:t, c - s:c + s].mean() > 0.5:
        mask |= 1
    if m[c - s:c + s, w - t:].mean() > 0.5:
        mask |= 2
    if m[h - t:, c - s:c + s].mean() > 0.5:
        mask |= 4
    if m[c - s:c + s, :t].mean() > 0.5:
        mask |= 8
    return mask


def rot_cw_mask(mask):
    out = 0
    for bit, nxt in ((1, 2), (2, 4), (4, 8), (8, 1)):
        if mask & bit:
            out |= nxt
    return out


def do_paths():
    """Bikin 16 tile jalan tanah yang menyambung otomatis (path_0..15) dari tile tanah di tileset.
    Bit: 1=atas 2=kanan 4=bawah 8=kiri."""
    tdir = os.path.join(OUT, "tiles")
    table = {}
    for name in ["dirt_corner", "dirt_t", "dirt_h", "dirt_v"]:
        im = Image.open(os.path.join(tdir, name + ".png")).convert("RGBA")
        mk = connections(im)
        print("  tile", name, "terhubung ke mask", mk)
        cur_im, cur_mk = im, mk
        for _ in range(4):
            if cur_mk not in table:
                table[cur_mk] = cur_im
            cur_im = cur_im.rotate(-90)
            cur_mk = rot_cw_mask(cur_mk)
    dirt = Image.open(os.path.join(tdir, "dirt.png")).convert("RGBA")
    table[0] = dirt
    sv, sh = table.get(5, dirt), table.get(10, dirt)
    for m_ in (1, 4):
        table.setdefault(m_, sv)
    for m_ in (2, 8):
        table.setdefault(m_, sh)
    # tile "T" (3 cabang) disusun dari tile persimpangan + tile lurus, lalu diputar ke 4 arah
    cross = table.get(15)
    if cross is None:
        cross = table.get(11) or table.get(14) or dirt
        table[15] = cross
    if 11 not in table and 7 not in table and 14 not in table and 13 not in table:
        t11 = cross.copy()                       # cabang: atas, kanan, kiri (bawah ditutup)
        t11.paste(sh.crop((0, 32, 64, 64)), (0, 32))
        cur_im, cur_mk = t11, 11
        for _ in range(4):
            table.setdefault(cur_mk, cur_im)
            cur_im = cur_im.rotate(-90)
            cur_mk = rot_cw_mask(cur_mk)
    for i in range(16):
        save(table.get(i, dirt), "tiles", f"path_{i}.png")
    print("  mask tersedia dari sheet:", sorted(k for k in table if k not in (0, 1, 2, 4, 8, 15)))


def save_walk(frames_by_dir, folder, name_fmt, hip, stride):
    """frames_by_dir: {arah: gambar_basis}. name_fmt contoh 'tri_walk_{d}_{i}.png'."""
    for d, base in frames_by_dir.items():
        mode = "side" if d in ("left", "right") else "front"
        for i, fr in enumerate(walk_cycle(base, mode, hip, stride)):
            save(fr, folder, name_fmt.format(d=d, i=i))


def do_optional():
    """Sheet opsional: tools/source_sheets/janitor.png dan rude.png (4 baris arah x 4 kolom), urutan baris: down,left,right,up."""
    for sheet, folder, fmt in (("janitor.png", "janitor", "jan_walk_{d}_{i}.png"), ("rude.png", "rude", "rude_walk_{d}_{i}.png")):
        if not os.path.exists(os.path.join(SRC, sheet)):
            continue
        img = load(sheet)
        boxes = grid_boxes(img, 4, 4)
        crops = [img.crop(b) for row in boxes for b in row]
        scale = VISITOR_TARGET_H / max(c.height for c in crops)
        fr = uniform(crops, scale)
        base = {d: fr[r * 4] for r, d in enumerate(VISITOR_DIRS)}
        if SYNTH_WALK:
            save_walk(base, folder, fmt, 0.58, 0.12)
        else:
            for r, d in enumerate(VISITOR_DIRS):
                for i in range(4):
                    save(fr[r * 4 + i], folder, fmt.format(d=d, i=i))
        print("  sprite opsional:", sheet)


def do_dino():
    img = load("dino_walk.png")
    boxes = grid_boxes(img, len(WALK_ROWS), WALK_COLS)
    crops = [img.crop(b) for row in boxes for b in row]
    scale = DINO_TARGET_W / max(c.width for c in crops)
    fr = uniform(crops, scale)
    if SYNTH_WALK:
        save_walk({d: fr[r * WALK_COLS] for r, d in enumerate(WALK_ROWS)}, "dino", "tri_walk_{d}_{i}.png", 0.68, 0.04)
    else:
        k = 0
        for d in WALK_ROWS:
            for i in range(WALK_COLS):
                save(fr[k], "dino", f"tri_walk_{d}_{i}.png")
                k += 1
    img = load("dino_eat_sleep.png")
    boxes = grid_boxes(img, 2, EAT_SLEEP_COLS)
    crops = [img.crop(b) for row in boxes for b in row]
    scale = DINO_TARGET_W / max(c.width for c in crops)
    fr = uniform(crops, scale)
    k = 0
    for name in ["eat", "sleep"]:
        for i in range(EAT_SLEEP_COLS):
            save(fr[k], "dino", f"tri_{name}_{i}.png")
            k += 1


def do_visitors():
    img = load("visitors.png")
    boxes = grouped_boxes(img, len(VISITOR_DIRS), VISITOR_GROUPS, VISITOR_FRAMES)
    crops = [img.crop(b) for row in boxes for b in row]
    scale = VISITOR_TARGET_H / max(c.height for c in crops)
    fr = uniform(crops, scale)
    per_row = VISITOR_GROUPS * VISITOR_FRAMES
    for g in range(VISITOR_GROUPS):
        if SYNTH_WALK:
            base = {d: fr[r * per_row + g * VISITOR_FRAMES] for r, d in enumerate(VISITOR_DIRS)}
            save_walk(base, "visitors", "v" + str(g) + "_{d}_{i}.png", 0.58, 0.12)
        else:
            for r, d in enumerate(VISITOR_DIRS):
                for f in range(VISITOR_FRAMES):
                    save(fr[r * per_row + g * VISITOR_FRAMES + f], "visitors", f"v{g}_{d}_{f}.png")


def do_enclosures():
    img = load("enclosures.png")
    boxes = grid_boxes(img, 1, 3)[0]
    crops = [img.crop(b) for b in boxes]
    scale = ENCLOSURE_TARGET_W / max(c.width for c in crops)
    for i, c in enumerate(crops):
        save(resize(c, scale), "enclosure", f"kandang_{i + 1}.png")


def do_tiles():
    img = load("tiles.png")
    boxes = grid_boxes(img, 4, 4)
    k = 0
    for row in boxes:
        for (x0, y0, x1, y1) in row:
            ins = int(0.06 * (x1 - x0))
            t = img.crop((x0 + ins, y0 + ins, x1 - ins, y1 - ins))
            save(t.convert("RGBa").resize((64, 64), Image.LANCZOS).convert("RGBA"), "tiles", f"{TILE_NAMES[k]}.png")
            k += 1


def do_facilities():
    img = load("facilities.png")
    boxes = grid_boxes(img, 2, 4)
    k = 0
    for row in boxes:
        for b in row:
            c = img.crop(b)
            save(resize(c, FACILITY_WIDTHS[k] / c.width), "facilities", f"{FACILITY_NAMES[k]}.png")
            k += 1


def do_icons():
    img = load("icons.png")
    boxes = grid_boxes(img, 2, 4)
    k = 0
    for row in boxes:
        for b in row:
            c = img.crop(b)
            save(resize(c, 44 / max(c.width, c.height)), "icons", f"{ICON_NAMES[k]}.png")
            k += 1


def do_launcher_icon():
    p = os.path.join(OUT, "dino", "tri_walk_down_0.png")
    d = Image.open(p).convert("RGBA")
    s = 150 / max(d.width, d.height)
    d = d.resize((round(d.width * s), round(d.height * s)), Image.NEAREST)
    bg = Image.new("RGBA", (192, 192), (88, 160, 62, 255))
    bg.alpha_composite(d, ((192 - d.width) // 2, (192 - d.height) // 2 + 6))
    bg.save(os.path.join(ROOT, "icon.png"))


if __name__ == "__main__":
    do_dino()
    do_visitors()
    do_enclosures()
    do_tiles()
    do_paths()
    do_facilities()
    do_icons()
    do_optional()
    do_launcher_icon()
    print("Selesai. Sprite ada di", OUT)
