# Prompt untuk generate ulang sprite (kandang pixel art & animasi jalan Triceratops)

Latar: minta "solid flat white background, no checkerboard", lalu hapus latar dengan remove.bg, simpan PNG.

## 1. Kandang (3 level, pixel art top-down)
16-bit pixel art, STRICTLY top-down overhead view (flat, not isometric, not 3D render), same style as a cute
pixel-art Triceratops: clean 1px dark outlines, limited 24-color palette, no anti-aliasing, no blur, no gradients,
no text. Three square dinosaur enclosures side by side, equal size, each seen from directly above, empty inside
(no dinosaur), with an open grassy interior and a gate in the middle of the bottom fence.
Level 1: simple wooden fence, plain grass with a few flowers.
Level 2: stronger stone-and-wood fence, rocks and a small pond.
Level 3: steel reinforced fence with a watchtower in one corner, trees, and a mud pit.
Solid flat white background, no ground shadow, no checkerboard.

## 2. Animasi jalan Triceratops (gerakan jelas)
Pixel art sprite sheet, 4 rows x 6 columns, each cell identical size, a cute blue Triceratops with cream horns,
cream frill spikes and darker blue spots (same design as the reference). Each row is a 6-frame WALK CYCLE with
CLEARLY DIFFERENT leg positions in every frame (contact, down, passing, contact with opposite legs, down, passing),
body bobbing up and down 2px, tail swaying, head slightly nodding.
Row 1: facing the camera (walking down). Row 2: full side profile facing LEFT. Row 3: full side profile facing
RIGHT. Row 4: seen from behind (walking up).
Clean 1px dark outline, limited palette, no anti-aliasing, no text, solid flat white background, evenly spaced.

## Cara memasang
1. Simpan hasil (latar sudah dihapus) menimpa tools/source_sheets/dino_walk.png dan tools/source_sheets/enclosures.png.
2. Kalau jumlah frame jalan bukan 4, ubah WALK_COLS di tools/slice_sheets.py (mis. 6).
3. Jalankan: python tools/slice_sheets.py   (butuh pip install pillow numpy)
4. Kalau interior kandang baru terlihat salah (dino keluar pagar), sesuaikan ENCLOSURE_INTERIOR di scripts/game_data.gd.

---
# Sprite tambahan (opsional, kalau mau gaya lebih bagus)
Aturan latar sama: "solid flat white background, no checkerboard", lalu hapus latar (remove.bg), simpan PNG.

## 3. Petugas kebersihan (taruh sebagai tools/source_sheets/janitor.png)
16-bit pixel art sprite sheet, 4 rows x 4 columns, identical cell size, same art style as the other zoo visitors
(chibi, clean 1px dark outline, limited palette, no anti-aliasing). A zoo janitor in an orange high-visibility vest
and cap, holding a broom in one hand. Rows: 1 facing camera (walking down), 2 side profile facing LEFT, 3 side profile
facing RIGHT, 4 seen from behind. 4 walking frames per row with clearly different leg positions. No text.

## 4. Pengunjung nakal / perokok (taruh sebagai tools/source_sheets/rude.png)
Same format as above. A rude zoo visitor: messy hair, black leather jacket, sunglasses, a cigarette in the mouth,
slouching walk, hands in pockets. Rows: down, left, right, up. 4 walking frames per row, clearly different legs.

## 5. Animasi jalan Triceratops/pengunjung asli (kalau mau ganti yang sintetis)
Lihat prompt nomor 2 di atas; untuk manusia: "4 rows x 4 columns, each row a 4-frame walk cycle: contact, passing,
contact with opposite leg, passing; arms swing opposite to legs". Setelah memasang, set SYNTH_WALK = False di tools/slice_sheets.py.
